export const PORT = process.env.DEV_PORT || process.env.PROD_PORT || process.env.PORT;

export const saltRounds = 10;